# Project One: Logs Analysis

## Overview

This project is a reporting tool that prints out plain text reports base database called News. This reporting tool is a Python program that uses the `psycopg2` module  The queries are run in Postgresql on a virtual machine.

The News database provides answers to the following questions:

1. What are the most popular three articles of all time?
2. Who are the most popular article writers of all time?
3. On which days did more than 1% of all requests lead to errors?

## Dependencies/Pre-Requisites

* Linux based virtual machine.
    * Virtualbox: https://www.virtualbox.org/wiki/Download_Old_Builds_5_1
    * VagrantUp: https://www.vagrantup.com/downloads.html
* The `psycopg2` module 

## Setup/Installation  

### Installing and Configuring the Virtual Machine

* This project makes use of a Linux based virtual machine. Vagrant and VirtualBox were used to install and manage the virtual machine used for this project.
 
* The configuration that was used to configure the virtual machine for this project was downloaded that the Udacity Github repository at the following link: https://github.com/udacity/fullstack-nanodegree-vm

* Use `vagrant up` to start the virtual machine. Please note it may take several minutes after running `vagrant` up to install the virtual machine, because an entrie virtual machine is being downloaded from the Internet.

* Run `vagant ssh` to run the virtual machine.

### The psycopg2 Library

* Install the `psycopg2` library with `pip install psycopg2`.

### Download the Data

* Download the data from Databases with SQL and Python Section the Udacity Fullstack Web Developer Nanodegree program on Udacity.com.
    * https://d17h27t6h515a5.cloudfront.net/topher/2016/August/57b5f748_newsdata/newsdata.zip
    * You will need to unzip this file after downloading it. You will find a file 
    named `newsdata.sql`, place this file in the `vagrant` directory.
    * To load the file `cd` into the `vagrant` directory and use the following
    command: `psql -d news -f newsdata.sql`.


## Using the News Database

* Once you loaded your data you can connect to your data base using `psql -d news`, and you can explore the tables using the `\dt` and `\d table` commands and `select` statements. The News database has the following tables:
    * articles
    * authors
    * log

 * To connect to `newsdb.py` using the `psycogp2` module:
     * `  db = psycopg2.connect("dbname=news") `

 * Use `vagrant up` to start your database.
 * Use `vagrant ssh` to run your database.
 * Use views to print out the answers.

 1. create view top_three_articles as select slug, count slug as pageviews from
    articles left join log on replace(log.path, '/article/', ')
    = articles.slug group by slug

 2. create view top_authors as select slug, count slug as pageviews
    from articles left join log on replace(log.path, '/article/', ')
    = articles.slug group by slug

 3. create view num_errors as select time, status, count(status)
    as num_errors group by time order by num_errors   
